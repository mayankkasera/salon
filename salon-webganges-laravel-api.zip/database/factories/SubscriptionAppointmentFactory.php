<?php

use Faker\Generator as Faker;

$factory->define(App\SubscriptionAppointment::class, function (Faker $faker) {
    return [
        //
    ];
});
