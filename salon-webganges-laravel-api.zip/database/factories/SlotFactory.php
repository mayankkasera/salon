<?php

use Faker\Generator as Faker;

$factory->define(App\Slot::class, function (Faker $faker) {
    return [
        //
    ];
});
